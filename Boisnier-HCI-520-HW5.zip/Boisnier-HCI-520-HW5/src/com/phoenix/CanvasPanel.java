package com.phoenix;

import javax.swing.*;
import java.awt.*;
import java.awt.dnd.*;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.util.HashMap;
import java.util.TooManyListenersException;

public class CanvasPanel extends JPanel{

    private double xAt = 0;
    private double yAt = 0;

    private boolean isFlags = false;
    JList<String> flags = new JList<>();

    private final JScrollBar xScrollA;
    private final JScrollBar xScrollB;
    private final JScrollBar yScrollA;
    private final JScrollBar yScrollB;
    private final JPanel c;

    private final HashMap<String, ImageIcon> nameToImage;

    public CanvasPanel(String[] countryNames, HashMap<String, ImageIcon> map, JFrame window) throws TooManyListenersException {
        nameToImage = map;
//---------------------------------------------------------------------Makes the "canvas"-------------------------------
        c = new JPanel();
        c.setSize(new Dimension(800, 800));
        c.setLayout(null);
        DropTarget t = new DropTarget();
        c.setDropTarget(t);
        JPanel bottomSection = new JPanel();
//---------------------------------------------------------------------The scrollbars-----------------------------------
        xScrollA = new JScrollBar();
        xScrollB = new JScrollBar();
        xScrollA.setMinimum(0);
        xScrollA.setMaximum(c.getWidth());
        xScrollB.setMinimum(0);
        xScrollB.setMaximum(c.getWidth());
        xScrollA.setOrientation(Adjustable.HORIZONTAL);
        xScrollB.setOrientation(Adjustable.HORIZONTAL);

        yScrollA = new JScrollBar();
        yScrollB = new JScrollBar();
        yScrollA.setMinimum(0);
        yScrollA.setMaximum(c.getHeight());
        yScrollB.setMinimum(0);
        yScrollB.setMaximum(c.getHeight());

        xScrollA.addAdjustmentListener(adjustmentEvent -> updateX(xScrollA, xScrollB));
        xScrollB.addAdjustmentListener(adjustmentEvent -> updateX(xScrollB, xScrollA));
        yScrollA.addAdjustmentListener(adjustmentEvent -> updateY(yScrollA, yScrollB));
        yScrollB.addAdjustmentListener(adjustmentEvent -> updateY(yScrollB, yScrollA));
//---------------------------------------------------------------------Country list and bottom scrollbar grouping-------
        GroupLayout group = new GroupLayout(bottomSection);
        bottomSection.setLayout(group);

        JPanel bottomBottom = new JPanel();
        flags.setListData(countryNames);
        flags.setVisibleRowCount(47);
        flags.setDragEnabled(true);
        flags.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrolly = new JScrollPane(flags);
        t.addDropTargetListener(new DropTargetListener() {
            @Override
            public void dragEnter(DropTargetDragEvent dropTargetDragEvent) {

            }

            @Override
            public void dragOver(DropTargetDragEvent dropTargetDragEvent) {

            }

            @Override
            public void dropActionChanged(DropTargetDragEvent dropTargetDragEvent) {

            }

            @Override
            public void dragExit(DropTargetEvent dropTargetEvent) {

            }

            @Override
            public void drop(DropTargetDropEvent dropTargetDropEvent) {
                drawFlag(c, flags.getSelectedValue());
            }
        });

        group.setHorizontalGroup(group.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addComponent(xScrollA).addComponent(bottomBottom));
        group.setVerticalGroup(group.createSequentialGroup().addComponent(xScrollA).addComponent(bottomBottom));
//---------------------------------------------------------------------Putting it all together--------------------------
        JPanel displayPane = new JPanel(new BorderLayout());
        displayPane.setPreferredSize(new Dimension(800, 800));
        displayPane.add(c, BorderLayout.CENTER);
        displayPane.add(yScrollA, BorderLayout.EAST);
        displayPane.add(xScrollA, BorderLayout.SOUTH);
        displayPane.add(xScrollB, BorderLayout.NORTH);
        displayPane.add(yScrollB, BorderLayout.WEST);
        window.add(displayPane);
        window.add(scrolly);
        window.addComponentListener(new ComponentAdapter() {
            public void componentResized(ComponentEvent componentEvent) {
                //I couldn't get this to work properly.
                //I almost completely broke my code, but thankfully someone taught me the IDE has VC.
                xScrollA.setMaximum(c.getWidth());
                xScrollB.setMaximum(c.getWidth());
                yScrollA.setMaximum(c.getHeight());
                yScrollB.setMaximum(c.getHeight());
            }
        });
        window.pack();
        //TODO change this
        window.setResizable(false);
    }

    /**
     * Updates the x scroll bars together and repaints the crosshairs.
     */
    private void updateX(JScrollBar xA, JScrollBar xB){
        drawCrosshairs(isFlags);
        if(xA.getValue()!=xAt){
            xB.setValue(xA.getValue());
            xAt = xA.getValue();
        }
        else{
            xA.setValue(xB.getValue());
            xAt = xB.getValue();
        }
        drawCrosshairs(isFlags);
    }

    /**
     * Updates the y scroll bars together and repaints the crosshairs.
     */
    private void updateY(JScrollBar yA, JScrollBar yB){
        drawCrosshairs(isFlags);
        if(yA.getValue()!=yAt){
            yB.setValue(yA.getValue());
            yAt = yA.getValue();
        }
        else{
            yA.setValue(yB.getValue());
            yAt = yB.getValue();
        }
        drawCrosshairs(isFlags);
    }

    /**
     * Surprise! It draws the crosshairs.
     */
    public void drawCrosshairs(boolean isFlags){
        if(!isFlags){
            Graphics g = c.getGraphics();
            g.setColor(c.getBackground());
            g.fillRect(0, 0, c.getWidth(), c.getHeight());
            g.setColor(Color.BLACK);
            g.fillRect((int) xAt-2, (int) yAt-15, 4, 30);
            g.fillRect((int) xAt-15, (int) yAt-2, 30, 4);
        }
        else{
            drawFlag(c, flags.getSelectedValue());
        }
    }

    /**
     * Draws the flag.
     */
    public void drawFlag(JPanel c, String flagName) {
        if(!isFlags) isFlags = true;
        c.setLayout(null);
        if (c.getComponents().length > 0) {
            c.remove(0);
            c.validate();
            c.repaint();
        }
        JLabel flagObj = new JLabel(nameToImage.get(flagName));
        flagObj.setBounds((int) xAt-75, (int) yAt-50, 150, 100);
        flagObj.setVisible(true);
        c.setOpaque(false);
        c.add(flagObj);
        c.validate();
        c.repaint();
    }

}
