package com.phoenix;

import javax.swing.*;
import java.awt.*;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Objects;
import java.util.Scanner;
import java.util.TooManyListenersException;

public class RunTheStuff implements Runnable {

    private String[] rawFlagNames;

    public RunTheStuff(int size){
        rawFlagNames = new String[size];
        InputStream str = Main.class.getClassLoader().getResourceAsStream("countryList.txt");
        Scanner scone = new Scanner(Objects.requireNonNull(str));
        rawFlagNames = new String[100];
        int i = 0;
        while (scone.hasNext()) {
            String input = scone.nextLine();
            rawFlagNames[i] = input;
            i++;
        }
    }

    @Override
    public void run() {

        JFrame circleHolder = new JFrame();
        circleHolder.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        circleHolder.setLayout(new FlowLayout());
        ImageIcon[] flagImages = new LoadingScreen(rawFlagNames.length).getFlagImages();
        HashMap<String, ImageIcon> nameToImage = new HashMap<>();
        for(int q = 0; q < flagImages.length; q++){
            nameToImage.put(rawFlagNames[q], flagImages[q]);
        }
        CanvasPanel p = null;
        try {
            p = new CanvasPanel(rawFlagNames, nameToImage, circleHolder);
        } catch (TooManyListenersException e) {
            e.printStackTrace();
        }
        circleHolder.add(p);
        circleHolder.pack();
        circleHolder.validate();
        circleHolder.repaint();
        circleHolder.setVisible(true);

    }
}
