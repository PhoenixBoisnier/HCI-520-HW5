package com.phoenix;

import javax.swing.*;
import java.awt.*;

public class ScrollPainter extends JPanel{

    private double xAt = 0;
    private double yAt = 0;

    private JPanel canvas;
    private JScrollBar xScrollA;
    private JScrollBar xScrollB;
    private JScrollBar yScrollA;
    private JScrollBar yScrollB;

    public ScrollPainter(int x, int y){
        canvas = new JPanel();
        canvas.setSize(x, y);
        this.setLayout(new BorderLayout());

        xScrollA = new JScrollBar();
        xScrollA.setMaximum(x);
        xScrollA.setOrientation(Adjustable.HORIZONTAL);
        xScrollA.addAdjustmentListener(event -> updateX(xScrollA, xScrollB));
        this.add(xScrollA, BorderLayout.NORTH);

        xScrollB = new JScrollBar();
        xScrollB.setMaximum(x);
        xScrollB.setOrientation(Adjustable.HORIZONTAL);
        xScrollB.addAdjustmentListener(event -> updateX(xScrollB, xScrollA));
        this.add(xScrollB, BorderLayout.SOUTH);

        this.add(canvas, BorderLayout.CENTER);

        /**
         *
         yScrollA = new JScrollBar();
         yScrollA.setMinimum(0);
         yScrollA.setMaximum(circleHolder.getHeight());

         yScrollB = new JScrollBar();
         yScrollB.setMinimum(0);
         yScrollB.setMaximum(circleHolder.getHeight());

         yScrollA.addAdjustmentListener(event -> updateY(yScrollA, yScrollB));
         yScrollB.addAdjustmentListener(event -> updateY(yScrollB, yScrollA));
         */
    }

    /**
     * Surprise! It draws the crosshairs.
     */
    /*
    public void drawCrosshairs(boolean shoShow){
        Graphics g = artwork.getGraphics();
        g.setColor(artwork.getBackground());
        g.fillRect(0, 0, artwork.getWidth(), artwork.getHeight());
        if(shoShow){
            g.setColor(Color.BLACK);
        }
        g.fillRect((int) xAt-2, (int) yAt-15, 4, 30);
        g.fillRect((int) xAt-15, (int) yAt-2, 30, 4);
    }

     */

    /**
     * Draws the flag.
     */
    /*
    private void drawFlag(String flagName) {
        artwork.setLayout(null);
        if (artwork.getComponents().length > 0) {
            artwork.remove(0);
            artwork.validate();
            artwork.repaint();
        }
        JLabel flagObj = new JLabel(cti.get(flagName));
        flagObj.setBounds((int) xAt-75, (int) yAt-50, 150, 100);
        flagObj.setVisible(true);
        artwork.add(flagObj);
        artwork.validate();
        artwork.repaint();
    }

     */


    /**
     * Updates the x scroll bars together and repaints the crosshairs.
     */

    private void updateX(JScrollBar xA, JScrollBar xB){
        Graphics g = this.getGraphics();
        g.setColor(this.getBackground());
        g.fillRect(0,0, this.getWidth(), this.getHeight());
        if(xA.getValue()!=xAt){
            xB.setValue(xA.getValue());
            xAt = xA.getValue();
        }
        else{
            xA.setValue(xB.getValue());
            xAt = xB.getValue();
        }
        g.setColor(Color.BLACK);
        g.fillRect((int) xAt-2+xA.getWidth(), (int) yAt-15, 4, 30);
        g.fillRect((int) xAt-15, (int) yAt-2, 30, 4);
    }

    /**
     * Updates the y scroll bars together and repaints the crosshairs.
     */
    /*
    private void updateY(JScrollBar yA, JScrollBar yB){
        drawCrosshairs(false);
        if(yA.getValue()!=yAt){
            yB.setValue(yA.getValue());
            yAt = yA.getValue();
        }
        else{
            yA.setValue(yB.getValue());
            yAt = yB.getValue();
        }
        drawCrosshairs(true);
    }

     */

}
