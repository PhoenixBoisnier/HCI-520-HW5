package com.phoenix;

import javax.swing.*;
import java.awt.*;

public class LoadingScreen {

    private ImageIcon[] fi;

    public LoadingScreen(int size){
        String[] myFlags = new String[size];
        for (int i = 0; i < myFlags.length; i++) {
            myFlags[i] = (i + ".png");
        }
        fi = new ImageIcon[100];
        FlagLoader loader = new FlagLoader(myFlags);
        loader.execute();

        JProgressBar progressBar = new JProgressBar(SwingConstants.VERTICAL, 0, 100);
        progressBar.setValue(0);
        Graphics2D g2d = SplashScreen.getSplashScreen().createGraphics();
        g2d.setColor(Color.GREEN);
        int sWidth = SplashScreen.getSplashScreen().getBounds().width-5;
        int sHeight = SplashScreen.getSplashScreen().getBounds().height-5;

        while(!loader.isDone()){
            if(progressBar.getValue()!=loader.getProgress()){
                progressBar.setValue(loader.getProgress());
                int width = (int) (loader.getProgress()/100.0 * sWidth);
                g2d.fillRect(5,sHeight-30, width, 30);
                SplashScreen.getSplashScreen().update();
            }
        }

        try {
            fi = loader.get();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Returns the final product from the loader worker.
     * @return
     */
    public ImageIcon[] getFlagImages(){
        return fi;
    }
}
