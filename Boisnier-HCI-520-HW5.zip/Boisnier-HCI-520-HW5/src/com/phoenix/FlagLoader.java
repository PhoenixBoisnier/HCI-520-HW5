package com.phoenix;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.util.Objects;

public class FlagLoader extends SwingWorker<ImageIcon[], Integer> {

    private final String[] names;

    public FlagLoader(String[] flagNames){
        names = flagNames;
    }

    @Override
    protected ImageIcon[] doInBackground() throws Exception {
        ImageIcon[] flagImages = new ImageIcon[100];
        for(int i = 0; i < 100; i++){
            ImageIcon flagIcon = new ImageIcon
                    (ImageIO.read(Objects.requireNonNull(Main.class.getClassLoader().getResource(names[i]))));
            flagImages[i] = flagIcon;
            setProgress(i);
        }
        return flagImages;
    }

}
