package com.phoenix;

import static javax.swing.SwingUtilities.invokeLater;

public class Main {

    public static void main(String[] args) {

        invokeLater(new RunTheStuff(100));

    }



}
